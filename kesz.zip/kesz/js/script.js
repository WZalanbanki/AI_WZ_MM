var aiTools = [
  {
    id: 1,
    name: "ChatGPT",
    developer: "OpenAI",
    description: "A világ legnépszerűbb AI chatbotja, amely szöveget generál, kérdésekre válaszol, kódot ír és kreatív feladatokban segít.",
    pricing: "freemium",
    pricingLabel: "Freemium",
    rating: 5,
    url: "https://chat.openai.com",
    icon: "https://upload.wikimedia.org/wikipedia/commons/0/04/ChatGPT_logo.svg",
    iconBg: "#10b98120",
    tags: ["szöveg", "kód"],
    detailDesc: "A ChatGPT az OpenAI GPT-4 modelljén alapuló chatbot, amely emberi szintű szövegértéssel és -generálással rendelkezik. Ingyenes szinten GPT-3.5, Plus előfizetéssel GPT-4 érhető el. Ideális íráshoz, kutatóhoz, kódoláshoz."
  },
  {
    id: 2,
    name: "Claude",
    developer: "Anthropic",
    description: "Megbízható, biztonságos és kreatív AI asszisztens, amely hosszú dokumentumokat és komplex elemzéseket is kezel.",
    pricing: "freemium",
    pricingLabel: "Freemium",
    rating: 5,
    url: "https://claude.ai",
    icon: "img/claude.webp",
    iconBg: "#8b5cf620",
    tags: ["szöveg", "kód"],
    detailDesc: "A Claude (Anthropic) az egyik legbiztonságosabb és legmegbízhatóbb AI asszisztens. Kiemelkedő dokumentumelemzési képességekkel rendelkezik, akár 200 000 tokenes kontextusablakkal. Kiváló jogi, pénzügyi és tudományos szövegek feldolgozásához."
  },
  {
    id: 3,
    name: "Midjourney",
    developer: "Midjourney, Inc.",
    description: "Képgeneráló AI, amely szöveges leírásokból gyönyörű, fotoreális és művészi képeket alkot.",
    pricing: "fizetős",
    pricingLabel: "Fizetős",
    rating: 5,
    url: "https://midjourney.com",
    icon: "img/Midjourney.png",
    iconBg: "#f59e0b20",
    tags: ["kép"],
    detailDesc: "A Midjourney a vezető AI képgeneráló eszközök egyike, amely Discord-alapon működik. Különböző stílusokat és esztétikákat képes utánozni, a fotoreálistól a festményszerűig. Havijegy szükséges, de a minőség felülmúlhatatlan."
  },
  {
    id: 4,
    name: "GitHub Copilot",
    developer: "GitHub / Microsoft",
    description: "AI-alapú kódkiegészítő, amely valós időben javasol kódrészleteket, függvényeket és dokumentációt.",
    pricing: "fizetős",
    pricingLabel: "Fizetős",
    rating: 4,
    url: "https://github.com/features/copilot",
    icon: "img/github-copilot-icon.webp",
    iconBg: "#6366f120",
    tags: ["kód"],
    detailDesc: "A GitHub Copilot 30+ programozási nyelvhez nyújt intelligens kódkiegészítést. Az OpenAI Codex modelljére épül, és közvetlenül integrálódik VS Code-ba, JetBrains IDE-kbe és más szerkesztőkbe. Ingyenes diákok és nyílt forráskódú fejlesztők számára."
  },
  {
    id: 5,
    name: "DALL·E 3",
    developer: "OpenAI",
    description: "OpenAI képgeneráló modellje, amely ChatGPT-vel integrálva pontos, részletes képeket alkot szöveges leírásokból.",
    pricing: "freemium",
    pricingLabel: "Freemium",
    rating: 4,
    url: "https://openai.com/dall-e-3",
    icon: "img/dalle3.png",
    iconBg: "#ec489920",
    tags: ["kép"],
    detailDesc: "A DALL·E 3 az OpenAI legújabb képgenerátora, amely ChatGPT-vel való integrációnak köszönhetően természetes nyelvi utasításokból precíz képeket hoz létre. Különösen erős szöveg képbe ágyazásában és komplex kompozíciókban."
  },
  {
    id: 6,
    name: "Gemini",
    developer: "Google DeepMind",
    description: "Google multimodális AI-ja, amely szöveg, kép, hang és kód feldolgozásában egyaránt kiemelkedő.",
    pricing: "freemium",
    pricingLabel: "Freemium",
    rating: 4,
    url: "https://gemini.google.com",
    icon: "https://upload.wikimedia.org/wikipedia/commons/8/8a/Google_Gemini_logo.svg",
    iconBg: "#3b82f620",
    tags: ["szöveg", "kép", "kód"],
    detailDesc: "A Google Gemini Ultra modellje az egyik legerőteljesebb multimodális AI, amely képes szöveg, kép, hang és videó egyidejű feldolgozására. Mélyen integrált a Google Workspace eszközeivel, így irodai munkához tökéletes."
  },
  {
    id: 7,
    name: "ElevenLabs",
    developer: "ElevenLabs",
    description: "Valósághű AI hangszintézis és hangklónozás, amely természetesnek hallható szöveget olvas fel.",
    pricing: "freemium",
    pricingLabel: "Freemium",
    rating: 5,
    url: "https://elevenlabs.io",
    icon: "img/ElevenLabs.png",
    iconBg: "#00e5a020",
    tags: ["hang"],
    detailDesc: "Az ElevenLabs a legreálisabb AI hangszintézis megoldást kínálja. Saját hangod klónozható néhány perces mintával, majd tetszőleges szöveget olvas fel hitelesen. Ingyenes szinten korlátozott karakterszám érhető el havonta."
  },
  {
    id: 8,
    name: "Perplexity AI",
    developer: "Perplexity AI, Inc.",
    description: "AI-alapú keresőmotor, amely valós idejű internetes kereséssel pontosan hivatkozott válaszokat ad.",
    pricing: "freemium",
    pricingLabel: "Freemium",
    rating: 4,
    url: "https://perplexity.ai",
    icon: "img/PerplexityAI.png",
    iconBg: "#0ea5e920",
    tags: ["szöveg"],
    detailDesc: "A Perplexity AI az AI és keresőmotor keresztezése. Minden válaszhoz forrásokat is megad, így ellenőrizhető az információ pontossága. Kiváló kutatáshoz, tényszerű kérdésekhez és naprakész információk megszerzéséhez."
  }
];

function renderStars(rating) {
  return Array.from({ length: 5 }, (_, i) =>
    `<span class="star ${i < rating ? 'filled' : 'empty'}">${i < rating ? '★' : '☆'}</span>`
  ).join('');
}

function getBadgeClass(pricing) {
  if (pricing === 'ingyenes') return 'badge-free';
  if (pricing === 'fizetős')  return 'badge-paid';
  return 'badge-freemium';
}

function renderCards(tools) {
  var grid  = document.getElementById('cardsGrid');
  var noRes = document.getElementById('noResults');

  if (tools.length === 0) {
    grid.innerHTML = '';
    noRes.classList.add('visible');
    return;
  }

  noRes.classList.remove('visible');
  grid.innerHTML = tools.map(t => {
    var imgHtml = t.icon ? `<img src="${t.icon}" alt="${t.name} logó">` : '';
    return `
      <div class="card" data-id="${t.id}">
        <div class="card-header">
          <div class="card-icon" style="background:${t.iconBg}">${imgHtml}</div>
          <span class="${getBadgeClass(t.pricing)}">${t.pricingLabel}</span>
        </div>
        <div class="card-name">${t.name}</div>
        <div class="card-developer">${t.developer}</div>
        <div class="card-desc">${t.description}</div>
        <div class="card-footer">
          <div>
            <div class="stars">${renderStars(t.rating)}</div>
            <div class="rating-label">${t.rating}/5 csillag</div>
          </div>
          <a href="${t.url}" target="_blank" rel="noopener" class="btn-visit">Megnézem →</a>
        </div>
      </div>
    `;
  }).join('');
}

function renderHistory(tools) {
  document.getElementById('historyGrid').innerHTML = tools.map(t => {
    var imgHtml = t.icon ? `<img src="${t.icon}" alt="${t.name} logó">` : '';
    return `
      <div class="history-card">
        <div class="history-img" style="background:${t.iconBg}">${imgHtml}</div>
        <div class="history-body">
          <div class="history-title">${t.name}</div>
          <div class="history-desc">${t.detailDesc}</div>
          <div class="history-meta">${t.developer} · ${t.pricingLabel}</div>
        </div>
      </div>
    `;
  }).join('');
}

let activeFilter = 'all';
let searchTerm   = '';

function getFiltered() {
  return aiTools.filter(t => {
    var matchFilter =
      activeFilter === 'all' ||
      t.pricing === activeFilter ||
      t.tags.includes(activeFilter);

    var matchSearch =
      !searchTerm ||
      t.name.toLowerCase().includes(searchTerm) ||
      t.developer.toLowerCase().includes(searchTerm) ||
      t.description.toLowerCase().includes(searchTerm) ||
      t.tags.some(tag => tag.includes(searchTerm));

    return matchFilter && matchSearch;
  });
}

function update() {
  var filtered = getFiltered();
  renderCards(filtered);

  var cnt = document.getElementById('searchCount');
  cnt.textContent = searchTerm
    ? `${filtered.length} találat "${searchTerm}" kifejezésre`
    : '';
}

document.getElementById('searchInput').addEventListener('input', e => {
  searchTerm = e.target.value.toLowerCase().trim();
  update();
});

document.getElementById('filterRow').addEventListener('click', e => {
  var chip = e.target.closest('.chip');
  if (!chip) return;
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  chip.classList.add('active');
  activeFilter = chip.dataset.filter;
  update();
});

renderCards(aiTools);
renderHistory(aiTools);