var ai_darabszam = 8; 

var chatbot_adatok = {
  koszones: "Szia! Miben segíthetek ma? Válassz egy kérdést az alábbiak közül!",
  kerdesek: [
    {
      q: "Melyik a legjobb ingyenes AI eszköz?",
      a: "Az ingyenes lehetőségek közül a **ChatGPT** (GPT-3.5) és a **Gemini** kiemelkedik. Ha kódhoz kell segítség, a **GitHub Copilot** diákoknak ingyenes!"
    },
    {
      q: "Mi a különbség ChatGPT és Claude között?",
      a: "Mindkettő kiváló chatbot! A **ChatGPT** erősebb a kreativitásban és kódolásban, míg a **Claude** megbízhatóbb hosszú dokumentumok elemzésénél és biztonságosabb válaszokat ad."
    },
    {
      q: "Melyik AI generál legjobb képeket?",
      a: "Képgenerálásban a **Midjourney** a legjobb minőségű eredményeket adja, de fizetős. A **DALL·E 3** ingyenesen elérhető ChatGPT-n keresztül és nagyon pontos."
    },
    {
      q: "Van ingyenes kódoló AI?",
      a: "Igen! A **GitHub Copilot** ingyenes diákok és nyílt forráskódú fejlesztők számára. Emellett a **ChatGPT** és **Claude** is segít kódolásban ingyenes szinten."
    },
    {
      q: "Mire való az ElevenLabs?",
      a: "Az **ElevenLabs** hangszintézisre specializálódott. Saját hangod klónozásával vagy előre elkészített hangokkal szövegből reális hanganyagot készíthetsz. Podcast-okhoz, videókhoz tökéletes!"
    },
    {
      q: "Hány eszköz szerepel az oldalon?",
      a: "Jelenleg **" + ai_darabszam + " AI eszköz** szerepel az oldalon, amelyek különböző kategóriákba tartoznak: szöveg, kép, kód és hang. Folyamatosan bővítjük a listát!"
    }
  ]
};

var uzenetek_doboz = document.getElementById('chatMessages');
var gombok_doboz = document.getElementById('chatQuestions');

function uzenetHozzaadas(szoveg, ki_kuldte) {
  var uj_div = document.createElement('div');
  uj_div.className = "msg " + ki_kuldte;

  uj_div.innerHTML = szoveg.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  
  uzenetek_doboz.appendChild(uj_div);

  uzenetek_doboz.scrollTop = uzenetek_doboz.scrollHeight;
}

function chatInditasa() {

  setTimeout(function() {
    uzenetHozzaadas(chatbot_adatok.koszones, 'bot');
  }, 200);

  var gombok_html = chatbot_adatok.kerdesek.map(function(elem, index) {
    return '<button class="q-btn" data-idx="' + index + '">' + elem.q + '</button>';
  }).join('');
  
  gombok_doboz.innerHTML = gombok_html;

  gombok_doboz.addEventListener('click', function(esemeny) {
    var kattintott_gomb = esemeny.target.closest('.q-btn');
    if (!kattintott_gomb) return;
    
    var gomb_szama = parseInt(kattintott_gomb.getAttribute('data-idx'));
    var kivalasztott_kerdes = chatbot_adatok.kerdesek[gomb_szama];

    uzenetHozzaadas(kivalasztott_kerdes.q, 'user');

    kattintott_gomb.disabled = true;
    kattintott_gomb.style.opacity = "0.5";
    kattintott_gomb.style.cursor = "default";

    setTimeout(function() {
      uzenetHozzaadas(kivalasztott_kerdes.a, 'bot');
    }, 600);
  });
}
document.addEventListener('DOMContentLoaded', chatInditasa);